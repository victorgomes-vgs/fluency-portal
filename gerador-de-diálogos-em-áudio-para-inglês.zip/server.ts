import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to wrap PCM in WAV header if needed
function convertAudioToWavDataUrl(base64Data: string, mimeType?: string): string {
  if (mimeType && (mimeType.includes('wav') || mimeType.includes('mp3') || mimeType.includes('mpeg'))) {
    return `data:${mimeType};base64,${base64Data}`;
  }

  // Gemini TTS default raw PCM (24000 Hz, 1 channel, 16-bit PCM little-endian)
  const pcmBuffer = Buffer.from(base64Data, 'base64');
  const dataSize = pcmBuffer.length;
  const numChannels = 1;
  const sampleRate = 24000;
  const bitsPerSample = 16;
  const header = Buffer.alloc(44);

  // RIFF chunk
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);

  // fmt subchunk
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
  header.writeUInt16LE(1, 20); // AudioFormat (1 = PCM)
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE((sampleRate * numChannels * bitsPerSample) / 8, 28);
  header.writeUInt16LE((numChannels * bitsPerSample) / 8, 32);
  header.writeUInt16LE(bitsPerSample, 34);

  // data subchunk
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  const wavBuffer = Buffer.concat([header, pcmBuffer]);
  return `data:audio/wav;base64,${wavBuffer.toString('base64')}`;
}

// Lazy initialization for Gemini client
function getGenAIClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is not defined.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API Routes

// 1. Healthcheck
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 2. Generate Dialogue Text with Vocabulary & Questions
app.post('/api/generate-dialogue-text', async (req, res) => {
  try {
    const { topic, level, speaker1Name, speaker2Name, context } = req.body;

    if (!topic || !level || !speaker1Name || !speaker2Name) {
      return res.status(400).json({ error: 'Missing required parameters (topic, level, speaker names).' });
    }

    const ai = getGenAIClient();

    const systemInstruction = `You are an expert English language teacher and curriculum creator.
Your goal is to generate natural, realistic dialogue in English for English language learners at level ${level}.
The dialogue MUST be between two distinct speakers: "${speaker1Name}" and "${speaker2Name}".
Return structured JSON with:
1. "title": Catchy title for the lesson dialogue.
2. "description": Short overview in Portuguese explaining what the dialogue teaches.
3. "lines": Array of objects, each containing "speakerName" (must strictly be "${speaker1Name}" or "${speaker2Name}") and "text" (natural English speech appropriate for level ${level}). Aim for 6 to 10 total turns.
4. "vocabulary": Array of 3 to 5 key words or expressions from the dialogue with "word", "type" (e.g. noun, verb, idiom), "definitionEn", "definitionPt", and an "example".
5. "questions": Array of 2 multiple-choice comprehension questions with "questionEn", "questionPt", "options" (4 choices), "correctAnswer" (0-indexed), and "explanationPt".`;

    const userPrompt = `Topic: ${topic}
Target English Level: ${level}
Speaker 1 Name: ${speaker1Name}
Speaker 2 Name: ${speaker2Name}
Additional Context/Instructions: ${context || 'None'}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            lines: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  speakerName: { type: Type.STRING },
                  text: { type: Type.STRING },
                },
                required: ['speakerName', 'text'],
              },
            },
            vocabulary: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  word: { type: Type.STRING },
                  type: { type: Type.STRING },
                  definitionEn: { type: Type.STRING },
                  definitionPt: { type: Type.STRING },
                  example: { type: Type.STRING },
                },
                required: ['word', 'definitionEn', 'definitionPt', 'example'],
              },
            },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  questionEn: { type: Type.STRING },
                  questionPt: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctAnswer: { type: Type.INTEGER },
                  explanationPt: { type: Type.STRING },
                },
                required: ['questionEn', 'questionPt', 'options', 'correctAnswer', 'explanationPt'],
              },
            },
          },
          required: ['title', 'description', 'lines', 'vocabulary', 'questions'],
        },
      },
    });

    const jsonText = response.text;
    if (!jsonText) {
      throw new Error('Empty response from Gemini model');
    }

    const data = JSON.parse(jsonText);
    res.json(data);
  } catch (err: any) {
    console.error('Error in /api/generate-dialogue-text:', err);
    res.status(500).json({ error: err.message || 'Failed to generate dialogue text' });
  }
});

// In-memory cache for synthesized audio
const audioCache = new Map<string, string>();

// 3. Generate Full Multi-Speaker Dialogue Audio
app.post('/api/generate-dialogue-audio', async (req, res) => {
  try {
    const { speakers, lines, instruction } = req.body;

    if (!speakers || !Array.isArray(speakers) || speakers.length < 2 || !lines || !Array.isArray(lines)) {
      return res.status(400).json({ error: 'Must provide at least 2 speakers and lines array.' });
    }

    const speaker1 = speakers[0];
    const speaker2 = speakers[1];

    const formattedTranscript = lines
      .map((line: { speakerName: string; text: string }) => `${line.speakerName}: ${line.text}`)
      .join('\n');

    // Check cache
    const cacheKey = `full_${speaker1.voice}_${speaker2.voice}_${formattedTranscript}`;
    if (audioCache.has(cacheKey)) {
      return res.json({ audioUrl: audioCache.get(cacheKey) });
    }

    const promptText = `TTS the following conversation between ${speaker1.name} and ${speaker2.name}. Read clearly for English learners:

${formattedTranscript}`;

    const ai = getGenAIClient();

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-tts-preview',
      contents: [{ parts: [{ text: promptText }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          multiSpeakerVoiceConfig: {
            speakerVoiceConfigs: [
              {
                speaker: speaker1.name,
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: speaker1.voice || 'Kore' },
                },
              },
              {
                speaker: speaker2.name,
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName: speaker2.voice || 'Puck' },
                },
              },
            ],
          },
        },
      },
    });

    const part = response.candidates?.[0]?.content?.parts?.[0];
    const base64Audio = part?.inlineData?.data;
    const mimeType = part?.inlineData?.mimeType;

    if (!base64Audio) {
      throw new Error('No audio data received from TTS service.');
    }

    const audioDataUrl = convertAudioToWavDataUrl(base64Audio, mimeType);
    
    // Store in cache
    audioCache.set(cacheKey, audioDataUrl);
    
    res.json({ audioUrl: audioDataUrl });
  } catch (err: any) {
    console.error('Error in /api/generate-dialogue-audio:', err);
    res.status(500).json({ error: err.message || 'Failed to generate dialogue audio' });
  }
});

// 4. Generate Single Line Audio
app.post('/api/generate-line-audio', async (req, res) => {
  try {
    const { text, voice, speakerName } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'Text parameter is required.' });
    }

    const ai = getGenAIClient();
    const voiceName = voice || 'Kore';

    const promptText = `Say clearly in natural English: ${text}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-tts-preview',
      contents: [{ parts: [{ text: promptText }] }],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const part = response.candidates?.[0]?.content?.parts?.[0];
    const base64Audio = part?.inlineData?.data;
    const mimeType = part?.inlineData?.mimeType;

    if (!base64Audio) {
      throw new Error('No audio data generated for single line.');
    }

    const audioDataUrl = convertAudioToWavDataUrl(base64Audio, mimeType);
    res.json({ audioUrl: audioDataUrl });
  } catch (err: any) {
    console.error('Error in /api/generate-line-audio:', err);
    res.status(500).json({ error: err.message || 'Failed to generate line audio' });
  }
});

// Vite Middleware & Static Setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
