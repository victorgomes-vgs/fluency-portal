import React, { useState, useEffect } from 'react';
import { PRESET_DIALOGUES } from './data/presets';
import { Dialogue, DialogueLine, SpeakerConfig, EnglishLevel } from './types';
import { Navbar } from './components/Navbar';
import { SpeakerSettings } from './components/SpeakerSettings';
import { DialogueEditor } from './components/DialogueEditor';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { LessonMaterial } from './components/LessonMaterial';
import { AIGeneratorModal } from './components/AIGeneratorModal';
import { PresetsModal } from './components/PresetsModal';
import { PrintableLessonSheet } from './components/PrintableLessonSheet';
import { Sparkles, Save, CheckCircle2, AlertCircle, Download } from 'lucide-react';

const LOCAL_STORAGE_KEY = 'english_studio_saved_dialogues_v1';

export default function App() {
  const [dialogue, setDialogue] = useState<Dialogue>(PRESET_DIALOGUES[0]);
  const [audioUrl, setAudioUrl] = useState<string | undefined>(undefined);
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  const [savedDialogues, setSavedDialogues] = useState<Dialogue[]>([]);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState<string | null>(null);

  const [isGeneratorOpen, setIsGeneratorOpen] = useState(false);
  const [isPresetsOpen, setIsPresetsOpen] = useState(false);
  const [isPrintView, setIsPrintView] = useState(false);
  const [activeLineId, setActiveLineId] = useState<string | undefined>(undefined);

  // Load saved dialogues on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (stored) {
        setSavedDialogues(JSON.parse(stored));
      }
    } catch (err) {
      console.error('Error loading saved dialogues:', err);
    }
  }, []);

  // Save current dialogue to localStorage
  const handleSaveDialogue = () => {
    try {
      const existingIdx = savedDialogues.findIndex((d) => d.id === dialogue.id);
      let updatedList: Dialogue[];

      if (existingIdx >= 0) {
        updatedList = [...savedDialogues];
        updatedList[existingIdx] = dialogue;
      } else {
        updatedList = [dialogue, ...savedDialogues];
      }

      setSavedDialogues(updatedList);
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedList));

      setSaveSuccessMessage(`Roteiro "${dialogue.title}" salvo com sucesso em Meus Salvos!`);
      setTimeout(() => setSaveSuccessMessage(null), 4000);
    } catch (err) {
      console.error('Error saving dialogue:', err);
    }
  };

  // Delete saved dialogue
  const handleDeleteSaved = (id: string) => {
    const updated = savedDialogues.filter((d) => d.id !== id);
    setSavedDialogues(updated);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
  };

  // Speaker update
  const handleSpeakerChange = (index: 0 | 1, updated: SpeakerConfig) => {
    const newSpeakers: [SpeakerConfig, SpeakerConfig] = [...dialogue.speakers] as [
      SpeakerConfig,
      SpeakerConfig,
    ];

    const oldName = newSpeakers[index].name;
    newSpeakers[index] = updated;

    // Synchronize lines if speaker name changed
    const updatedLines = dialogue.lines.map((l) => {
      if (l.speakerId === updated.id || l.speakerName === oldName) {
        return {
          ...l,
          speakerId: updated.id,
          speakerName: updated.name,
        };
      }
      return l;
    });

    setDialogue({
      ...dialogue,
      speakers: newSpeakers,
      lines: updatedLines,
    });

    // Invalidate old audio
    setAudioUrl(undefined);
  };

  // Lines update
  const handleLinesChange = (newLines: DialogueLine[]) => {
    setDialogue({
      ...dialogue,
      lines: newLines,
    });
    setAudioUrl(undefined);
  };

  // Generate Multi-Speaker Full Dialogue Audio
  const handleGenerateFullAudio = async (): Promise<string | null> => {
    try {
      setIsGeneratingAudio(true);
      setAudioError(null);

      const response = await fetch('/api/generate-dialogue-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          speakers: dialogue.speakers,
          lines: dialogue.lines,
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Falha ao gerar o áudio do diálogo com a API Gemini.');
      }

      setAudioUrl(data.audioUrl);
      return data.audioUrl;
    } catch (err: any) {
      console.error('Error generating dialogue audio:', err);
      setAudioError(
        err.message || 'Erro ao comunicar com o servidor de síntese de áudio. Tente novamente.'
      );
      return null;
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  // Select preset or saved dialogue
  const handleSelectPreset = (preset: Dialogue) => {
    setDialogue(preset);
    setAudioUrl(undefined);
    setAudioError(null);
  };

  // AI Generator output handler
  const handleAIGenerated = (data: {
    title: string;
    description: string;
    level: EnglishLevel;
    lines: { speakerName: string; text: string }[];
    vocabulary: any[];
    questions: any[];
    speaker1Name: string;
    speaker2Name: string;
  }) => {
    const speaker1: SpeakerConfig = {
      id: 'speaker_a',
      name: data.speaker1Name,
      voice: 'Kore',
      gender: 'female',
      avatarColor: 'bg-emerald-600',
    };

    const speaker2: SpeakerConfig = {
      id: 'speaker_b',
      name: data.speaker2Name,
      voice: 'Puck',
      gender: 'male',
      avatarColor: 'bg-blue-600',
    };

    const parsedLines: DialogueLine[] = data.lines.map((l, idx) => {
      const isSpeaker1 = l.speakerName.toLowerCase().trim() === data.speaker1Name.toLowerCase().trim();
      return {
        id: `ai_line_${Date.now()}_${idx}`,
        speakerId: isSpeaker1 ? speaker1.id : speaker2.id,
        speakerName: isSpeaker1 ? speaker1.name : speaker2.name,
        text: l.text,
      };
    });

    const newDialogue: Dialogue = {
      id: `custom_${Date.now()}`,
      title: data.title,
      description: data.description,
      level: data.level,
      category: 'Gerado por IA',
      speakers: [speaker1, speaker2],
      lines: parsedLines,
      vocabulary: data.vocabulary,
      questions: data.questions,
    };

    setDialogue(newDialogue);
    setAudioUrl(undefined);
    setAudioError(null);
  };

  // Download audio WAV file (or generate then download if not ready yet)
  const handleDownloadAudio = async () => {
    let targetUrl = audioUrl;

    if (!targetUrl) {
      targetUrl = (await handleGenerateFullAudio()) || undefined;
    }

    if (targetUrl) {
      const link = document.createElement('a');
      link.href = targetUrl;
      link.download = `${dialogue.title.replace(/[^a-zA-Z0-9_-]/g, '_')}_Audio.wav`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  if (isPrintView) {
    return <PrintableLessonSheet dialogue={dialogue} onClose={() => setIsPrintView(false)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        onOpenGenerator={() => setIsGeneratorOpen(true)}
        onOpenPresets={() => setIsPresetsOpen(true)}
        onTogglePrintView={() => setIsPrintView(true)}
        isPrintView={isPrintView}
        hasAudio={!!audioUrl}
        onDownloadAudio={handleDownloadAudio}
        onSaveDialogue={handleSaveDialogue}
        savedCount={savedDialogues.length}
      />

      {/* Main Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Save Confirmation Toast Banner */}
        {saveSuccessMessage && (
          <div className="mb-6 p-4 bg-emerald-950/90 border border-emerald-500/80 rounded-2xl text-xs text-emerald-200 flex items-center justify-between shadow-lg animate-fadeIn">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
              <span className="font-semibold text-sm">{saveSuccessMessage}</span>
            </div>
            <button
              onClick={() => setIsPresetsOpen(true)}
              className="px-3 py-1 bg-emerald-500 text-slate-950 font-bold rounded-lg text-xs hover:bg-emerald-400 transition-colors"
            >
              Ver em Meus Salvos →
            </button>
          </div>
        )}

        {/* Banner / Title Header */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
          <div className="space-y-1 relative z-10">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Nível {dialogue.level}
              </span>
              <span className="text-xs text-slate-400 font-medium">{dialogue.category}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-100 tracking-tight">
              {dialogue.title}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">{dialogue.description}</p>
          </div>

          <div className="flex items-center gap-2 relative z-10 flex-wrap">
            <button
              onClick={handleSaveDialogue}
              className="flex items-center gap-2 px-3.5 py-2.5 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-300 border border-emerald-700/80 text-xs font-bold rounded-xl transition-all shadow-sm"
              title="Salvar este roteiro"
            >
              <Save className="w-4 h-4 text-emerald-400" />
              <span>Salvar Roteiro</span>
            </button>

            <button
              onClick={() => setIsGeneratorOpen(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700/80 text-xs font-semibold rounded-xl transition-all shadow-sm"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Trocar Assunto com IA</span>
            </button>
          </div>
        </div>

        {/* Audio Error Alert */}
        {audioError && (
          <div className="mb-6 p-4 bg-rose-950/80 border border-rose-800/80 rounded-2xl text-xs text-rose-200 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Ocorreu um problema na geração do áudio:</p>
              <p className="mt-0.5 text-rose-300">{audioError}</p>
            </div>
          </div>
        )}

        {/* Primary Audio Player Bar */}
        <AudioPlayerBar
          audioUrl={audioUrl}
          isGeneratingAudio={isGeneratingAudio}
          onGenerateAudio={handleGenerateFullAudio}
          onDownloadAudio={handleDownloadAudio}
        />

        {/* Two-Column Grid layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Speaker Configuration & Dialogue Line Editor */}
          <div className="lg:col-span-8 space-y-6">
            <SpeakerSettings speakers={dialogue.speakers} onChangeSpeaker={handleSpeakerChange} />

            <DialogueEditor
              lines={dialogue.lines}
              speakers={dialogue.speakers}
              onChangeLines={handleLinesChange}
              activeLineId={activeLineId}
            />
          </div>

          {/* Right Column: Vocabulary, Exercises & Classroom Notes */}
          <div className="lg:col-span-4 space-y-6">
            <LessonMaterial vocabulary={dialogue.vocabulary} questions={dialogue.questions} />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 text-slate-500 py-6 text-center text-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© Estúdio de Diálogos com Áudio IA para Aulas de Inglês • Gemini Multi-Speaker TTS</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>2 Vozes Simultâneas</span>
            <span>•</span>
            <span>Ajuste de Velocidade</span>
            <span>•</span>
            <span>Exportação em WAV</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AIGeneratorModal
        isOpen={isGeneratorOpen}
        onClose={() => setIsGeneratorOpen(false)}
        onGenerated={handleAIGenerated}
      />

      <PresetsModal
        isOpen={isPresetsOpen}
        onClose={() => setIsPresetsOpen(false)}
        onSelectPreset={handleSelectPreset}
        savedDialogues={savedDialogues}
        onDeleteSaved={handleDeleteSaved}
        currentId={dialogue.id}
      />
    </div>
  );
}
