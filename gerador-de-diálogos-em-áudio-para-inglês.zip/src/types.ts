export type EnglishLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export type VoiceName = 'Kore' | 'Puck' | 'Charon' | 'Zephyr' | 'Fenrir';

export interface VoiceOption {
  id: VoiceName;
  name: string;
  gender: 'female' | 'male';
  description: string;
  recommendedFor: string;
}

export interface SpeakerConfig {
  id: string; // e.g. 'speaker_a' or 'speaker_b'
  name: string; // e.g. 'Anna', 'Mark', 'Teacher', 'Student'
  voice: VoiceName;
  gender: 'female' | 'male';
  avatarColor: string;
}

export interface DialogueLine {
  id: string;
  speakerId: string;
  speakerName: string;
  text: string;
  audioUrl?: string; // individual line audio if generated
}

export interface VocabItem {
  word: string;
  type?: string; // noun, verb, idiom, etc.
  definitionEn: string;
  definitionPt: string;
  example: string;
}

export interface QuestionItem {
  questionEn: string;
  questionPt: string;
  options: string[];
  correctAnswer: number; // index of correct option
  explanationPt: string;
}

export interface Dialogue {
  id: string;
  title: string;
  description: string;
  level: EnglishLevel;
  category: string;
  speakers: [SpeakerConfig, SpeakerConfig];
  lines: DialogueLine[];
  fullAudioUrl?: string;
  vocabulary?: VocabItem[];
  questions?: QuestionItem[];
}

export interface GenerateTextRequest {
  topic: string;
  level: EnglishLevel;
  speaker1Name: string;
  speaker2Name: string;
  context?: string;
}

export interface GenerateAudioRequest {
  speakers: SpeakerConfig[];
  lines: { speakerName: string; text: string }[];
  instruction?: string;
}
