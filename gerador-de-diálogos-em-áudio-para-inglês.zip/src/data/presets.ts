import { Dialogue } from '../types';

export const VOICE_OPTIONS = [
  {
    id: 'Kore' as const,
    name: 'Kore (Feminina - Clara e Suave)',
    gender: 'female' as const,
    description: 'Voz feminina natural, articulada e amigável. Ótima para professoras, guias e conversas do dia a dia.',
    recommendedFor: 'Interlocutor A / Professora / Atendente'
  },
  {
    id: 'Puck' as const,
    name: 'Puck (Masculino - Jovial e Dinâmico)',
    gender: 'male' as const,
    description: 'Voz masculina expressiva e expressiva. Excelente para diálogos casuais e amigos.',
    recommendedFor: 'Interlocutor B / Estudante / Amigo'
  },
  {
    id: 'Zephyr' as const,
    name: 'Zephyr (Feminina - Calma e Elegante)',
    gender: 'female' as const,
    description: 'Voz feminina corporativa, calma e fluida. Ideal para reuniões de trabalho e entrevistas.',
    recommendedFor: 'Entrevistadora / Gerente / Hotelaria'
  },
  {
    id: 'Charon' as const,
    name: 'Charon (Masculino - Profundo e Formal)',
    gender: 'male' as const,
    description: 'Voz masculina grave, séria e profissional. Perfeita para cenários executivos e oficiais.',
    recommendedFor: 'Diretor / Médico / Agente de Aeroporto'
  },
  {
    id: 'Fenrir' as const,
    name: 'Fenrir (Masculino - Descontraído e Direto)',
    gender: 'male' as const,
    description: 'Voz masculina moderna com cadência jovem. Perfeita para bate-papos e rotina.',
    recommendedFor: 'Colega de trabalho / Cliente / Turista'
  }
];

export const PRESET_DIALOGUES: Dialogue[] = [
  {
    id: 'preset_coffee_shop',
    title: 'Ordering Coffee & Pastry',
    description: 'Um diálogo prático em uma cafeteria em Londres, ideal para nivel A1/A2.',
    level: 'A1',
    category: 'Cafeteria & Restaurante',
    speakers: [
      {
        id: 'speaker_a',
        name: 'Barista (Emma)',
        voice: 'Kore',
        gender: 'female',
        avatarColor: 'bg-emerald-600'
      },
      {
        id: 'speaker_b',
        name: 'Customer (David)',
        voice: 'Puck',
        gender: 'male',
        avatarColor: 'bg-blue-600'
      }
    ],
    lines: [
      {
        id: 'c1',
        speakerId: 'speaker_a',
        speakerName: 'Emma',
        text: 'Good morning! Welcome to London Beans. What can I get started for you today?'
      },
      {
        id: 'c2',
        speakerId: 'speaker_b',
        speakerName: 'David',
        text: 'Hi there! Could I get a medium oat milk latte, please?'
      },
      {
        id: 'c3',
        speakerId: 'speaker_a',
        speakerName: 'Emma',
        text: 'Sure thing! Would you like that iced or hot?'
      },
      {
        id: 'c4',
        speakerId: 'speaker_b',
        speakerName: 'David',
        text: 'Iced, please. And do you have any fresh croissant left?'
      },
      {
        id: 'c5',
        speakerId: 'speaker_a',
        speakerName: 'Emma',
        text: 'Yes! We just pulled warm butter croissants out of the oven.'
      },
      {
        id: 'c6',
        speakerId: 'speaker_b',
        speakerName: 'David',
        text: 'Perfect! I will take one of those too.'
      },
      {
        id: 'c7',
        speakerId: 'speaker_a',
        speakerName: 'Emma',
        text: 'Awesome. That comes to eight pounds and fifty pence. Cash or card?'
      },
      {
        id: 'c8',
        speakerId: 'speaker_b',
        speakerName: 'David',
        text: 'Card, please. Here you go. Thank you so much!'
      }
    ],
    vocabulary: [
      {
        word: 'Oat milk',
        type: 'substantivo',
        definitionEn: 'A plant-based milk alternative made from oats.',
        definitionPt: 'Leite de aveia (alternativa vegetal ao leite de vaca).',
        example: 'Could I get an oat milk latte?'
      },
      {
        word: 'What can I get started for you?',
        type: 'expressão',
        definitionEn: 'A polite greeting used by servers to ask what you want to order.',
        definitionPt: 'Expressão muito comum de atendentes: "O que posso servir para você?"',
        example: 'Good morning! What can I get started for you?'
      },
      {
        word: 'That comes to...',
        type: 'expressão',
        definitionEn: 'Used to announce the total cost of a purchase.',
        definitionPt: 'Expressão usada para informar a conta: "Dá um total de..."',
        example: 'That comes to eight pounds and fifty pence.'
      }
    ],
    questions: [
      {
        questionEn: 'What kind of milk does David request in his latte?',
        questionPt: 'Que tipo de leite David solicita em seu café com leite?',
        options: ['Whole milk', 'Oat milk', 'Almond milk', 'Skim milk'],
        correctAnswer: 1,
        explanationPt: 'David pede um "medium oat milk latte".'
      },
      {
        questionEn: 'How much does David pay in total?',
        questionPt: 'Quanto David paga no total?',
        options: ['£5.00', '£7.50', '£8.50', '£10.00'],
        correctAnswer: 2,
        explanationPt: 'A atendente Emma fala: "That comes to eight pounds and fifty pence" (£8.50).'
      }
    ]
  },
  {
    id: 'preset_airport_checkin',
    title: 'Airport Check-in & Luggage',
    description: 'Diálogo essencial para viagens: fazendo check-in no aeroporto e enviando bagagem.',
    level: 'A2',
    category: 'Viagens & Aeroporto',
    speakers: [
      {
        id: 'speaker_a',
        name: 'Agent (Sarah)',
        voice: 'Zephyr',
        gender: 'female',
        avatarColor: 'bg-purple-600'
      },
      {
        id: 'speaker_b',
        name: 'Passenger (Michael)',
        voice: 'Fenrir',
        gender: 'male',
        avatarColor: 'bg-indigo-600'
      }
    ],
    lines: [
      {
        id: 'a1',
        speakerId: 'speaker_a',
        speakerName: 'Sarah',
        text: 'Good afternoon, sir. May I see your passport and flight booking confirmation?'
      },
      {
        id: 'a2',
        speakerId: 'speaker_b',
        speakerName: 'Michael',
        text: 'Here you go! I am flying to New York on flight British Airways 178.'
      },
      {
        id: 'a3',
        speakerId: 'speaker_a',
        speakerName: 'Sarah',
        text: 'Thank you, Michael. Are you checking in any bags today?'
      },
      {
        id: 'a4',
        speakerId: 'speaker_b',
        speakerName: 'Michael',
        text: 'Just this one suitcase, and I have a carry-on backpack with me.'
      },
      {
        id: 'a5',
        speakerId: 'speaker_a',
        speakerName: 'Sarah',
        text: 'Please place your suitcase on the scale. Perfect, twenty-one kilograms. Would you prefer a window or an aisle seat?'
      },
      {
        id: 'a6',
        speakerId: 'speaker_b',
        speakerName: 'Michael',
        text: 'An aisle seat near the front would be fantastic if available.'
      },
      {
        id: 'a7',
        speakerId: 'speaker_a',
        speakerName: 'Sarah',
        text: 'All set! Here is your boarding pass. Gate 14B begins boarding at four forty-five.'
      }
    ],
    vocabulary: [
      {
        word: 'Carry-on',
        type: 'substantivo',
        definitionEn: 'Small luggage that a passenger can take onto the airplane with them.',
        definitionPt: 'Bagagem de mão (mochila ou mala pequena que vai na cabine).',
        example: 'I have a carry-on backpack.'
      },
      {
        word: 'Aisle seat',
        type: 'substantivo',
        definitionEn: 'A seat next to the walkway in the middle of the airplane.',
        definitionPt: 'Assento no corredor do avião.',
        example: 'Would you prefer a window or an aisle seat?'
      },
      {
        word: 'Boarding pass',
        type: 'substantivo',
        definitionEn: 'A document provided by an airline giving a passenger permission to board.',
        definitionPt: 'Cartão de embarque.',
        example: 'Here is your boarding pass.'
      }
    ],
    questions: [
      {
        questionEn: 'Where is Michael flying to?',
        questionPt: 'Para onde Michael está voando?',
        options: ['London', 'New York', 'Paris', 'Tokyo'],
        correctAnswer: 1,
        explanationPt: 'Michael menciona: "I am flying to New York".'
      },
      {
        questionEn: 'What seat preference does Michael choose?',
        questionPt: 'Qual preferência de assento Michael escolhe?',
        options: ['Window seat', 'Aisle seat', 'Middle seat', 'No preference'],
        correctAnswer: 1,
        explanationPt: 'Michael pede um "aisle seat near the front" (assento no corredor).'
      }
    ]
  },
  {
    id: 'preset_job_interview',
    title: 'Professional Job Interview',
    description: 'Diálogo corporativo nível B1/B2 sobre experiências anteriores e habilidades.',
    level: 'B1',
    category: 'Trabalho & Negócios',
    speakers: [
      {
        id: 'speaker_a',
        name: 'Interviewer (Mr. Vance)',
        voice: 'Charon',
        gender: 'male',
        avatarColor: 'bg-slate-700'
      },
      {
        id: 'speaker_b',
        name: 'Candidate (Jessica)',
        voice: 'Kore',
        gender: 'female',
        avatarColor: 'bg-teal-600'
      }
    ],
    lines: [
      {
        id: 'j1',
        speakerId: 'speaker_a',
        speakerName: 'Mr. Vance',
        text: 'Welcome Jessica. Thank you for coming in today. To start off, could you tell me a bit about your professional background?'
      },
      {
        id: 'j2',
        speakerId: 'speaker_b',
        speakerName: 'Jessica',
        text: 'Thank you for having me, Mr. Vance! Over the past four years, I worked as a digital marketing specialist, managing international social campaigns.'
      },
      {
        id: 'j3',
        speakerId: 'speaker_a',
        speakerName: 'Mr. Vance',
        text: 'Impressive. How do you handle tight deadlines and high-pressure situations when launching a campaign?'
      },
      {
        id: 'j4',
        speakerId: 'speaker_b',
        speakerName: 'Jessica',
        text: 'I prioritize tasks based on impact, maintain clear communication with my team, and stay highly adaptable under pressure.'
      },
      {
        id: 'j5',
        speakerId: 'speaker_a',
        speakerName: 'Mr. Vance',
        text: 'Excellent. What motivated you to apply for this specific managerial position at our firm?'
      },
      {
        id: 'j6',
        speakerId: 'speaker_b',
        speakerName: 'Jessica',
        text: 'Your company is known for innovation in edtech, and I am eager to leverage my skills to lead creative, global projects.'
      }
    ],
    vocabulary: [
      {
        word: 'Leverage',
        type: 'verbo',
        definitionEn: 'To use something to maximum advantage.',
        definitionPt: 'Aproveitar / Potencializar habilidades para tirar vantagem positiva.',
        example: 'I am eager to leverage my skills to lead creative projects.'
      },
      {
        word: 'Tight deadlines',
        type: 'expressão',
        definitionEn: 'A strict time limit with little flexibility.',
        definitionPt: 'Prazos apertados / Prazos curtos.',
        example: 'How do you handle tight deadlines?'
      },
      {
        word: 'To start off',
        type: 'expressão',
        definitionEn: 'To begin a conversation or meeting.',
        definitionPt: 'Para começar / Para dar início.',
        example: 'To start off, could you tell me about your background?'
      }
    ],
    questions: [
      {
        questionEn: 'How many years of experience does Jessica have in digital marketing?',
        questionPt: 'Quantos anos de experiência Jessica tem em marketing digital?',
        options: ['Two years', 'Three years', 'Four years', 'Five years'],
        correctAnswer: 2,
        explanationPt: 'Jessica diz: "Over the past four years, I worked as a digital marketing specialist".'
      }
    ]
  }
];
