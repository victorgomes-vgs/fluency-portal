import React, { useState } from 'react';
import { EnglishLevel } from '../types';
import { Sparkles, X, Loader2, BookOpen, Layers } from 'lucide-react';

interface AIGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerated: (data: {
    title: string;
    description: string;
    level: EnglishLevel;
    lines: { speakerName: string; text: string }[];
    vocabulary: any[];
    questions: any[];
    speaker1Name: string;
    speaker2Name: string;
  }) => void;
}

export const AIGeneratorModal: React.FC<AIGeneratorModalProps> = ({
  isOpen,
  onClose,
  onGenerated,
}) => {
  const [topic, setTopic] = useState('');
  const [level, setLevel] = useState<EnglishLevel>('A2');
  const [speaker1Name, setSpeaker1Name] = useState('Anna');
  const [speaker2Name, setSpeaker2Name] = useState('Mark');
  const [context, setContext] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const quickTopics = [
    { name: 'Pedindo Café & Lanche', level: 'A1', desc: 'At a Coffee Shop' },
    { name: 'Check-in no Hotel', level: 'A2', desc: 'Hotel Reservation' },
    { name: 'Entrevista de Emprego', level: 'B1', desc: 'Job Interview' },
    { name: 'Pedindo Informação de Direção', level: 'A2', desc: 'Asking for Directions' },
    { name: 'Consulta Médica', level: 'B2', desc: 'At the Doctor’s Clinic' },
    { name: 'Negociando um Preço / Compras', level: 'B1', desc: 'Shopping & Bargaining' },
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch('/api/generate-dialogue-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          level,
          speaker1Name,
          speaker2Name,
          context,
        }),
      });

      const data = await response.json();

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Erro ao gerar o diálogo com Gemini');
      }

      onGenerated({
        title: data.title,
        description: data.description,
        level,
        lines: data.lines,
        vocabulary: data.vocabulary,
        questions: data.questions,
        speaker1Name,
        speaker2Name,
      });

      onClose();
    } catch (err: any) {
      console.error('Error in AI dialogue generator:', err);
      setError(err.message || 'Falha ao conectar à IA Gemini. Verifique a chave de API.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl text-slate-100 shadow-2xl overflow-hidden relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-amber-500/20 to-indigo-500/20 rounded-xl border border-amber-500/30">
              <Sparkles className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Criar Diálogo com Inteligência Artificial</h3>
              <p className="text-xs text-slate-400">Gere automaticamente conversas em inglês com vocabulário e exercícios</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleGenerate} className="p-6 overflow-y-auto space-y-5">
          {error && (
            <div className="p-3.5 bg-rose-950/60 border border-rose-800/80 rounded-xl text-xs text-rose-300">
              {error}
            </div>
          )}

          {/* Preset Topics Suggestions */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span>Sugestões Rápidas de Tópicos para Aula:</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {quickTopics.map((item) => (
                <button
                  key={item.name}
                  type="button"
                  onClick={() => {
                    setTopic(item.desc);
                    setLevel(item.level as EnglishLevel);
                  }}
                  className="p-2.5 text-left bg-slate-950/60 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 rounded-xl transition-all group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-200 group-hover:text-indigo-300 line-clamp-1">
                      {item.name}
                    </span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300">
                      {item.level}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Topic Input */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Assunto / Cenário do Diálogo *
            </label>
            <input
              type="text"
              required
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Ex: Ordering food in a vegan restaurant in London"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-3 text-sm text-slate-100 focus:outline-none transition-colors"
            />
          </div>

          {/* Level & Speakers */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Nível de Inglês (CEFR)
              </label>
              <select
                value={level}
                onChange={(e) => setLevel(e.target.value as EnglishLevel)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none transition-colors"
              >
                <option value="A1">A1 - Iniciante (Iniciante Absoluto)</option>
                <option value="A2">A2 - Básico (Elementary)</option>
                <option value="B1">B1 - Intermediário (Intermediate)</option>
                <option value="B2">B2 - Pós-Intermediário (Upper-Inter)</option>
                <option value="C1">C1 - Avançado (Advanced)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Nome Personagem 1
              </label>
              <input
                type="text"
                value={speaker1Name}
                onChange={(e) => setSpeaker1Name(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Nome Personagem 2
              </label>
              <input
                type="text"
                value={speaker2Name}
                onChange={(e) => setSpeaker2Name(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Extra Context */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Instruções Adicionais para a IA (Opcional)
            </label>
            <input
              type="text"
              value={context}
              onChange={(e) => setContext(e.target.value)}
              placeholder="Ex: Incluir vocabulário sobre pagamento com cartão de crédito"
              className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-2.5 text-xs text-slate-100 focus:outline-none transition-colors"
            />
          </div>

          {/* Footer Submit */}
          <div className="pt-2 flex justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
            >
              Cancelar
            </button>

            <button
              type="submit"
              disabled={isLoading || !topic.trim()}
              className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 rounded-xl shadow-md shadow-indigo-600/30 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Gerando Diálogo em Inglês...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Gerar Diálogo com IA</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
