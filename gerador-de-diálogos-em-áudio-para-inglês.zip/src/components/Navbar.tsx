import React from 'react';
import { Mic, Sparkles, BookOpen, Download, FileText, Save, FolderCheck } from 'lucide-react';

interface NavbarProps {
  onOpenGenerator: () => void;
  onOpenPresets: () => void;
  onTogglePrintView: () => void;
  isPrintView: boolean;
  hasAudio: boolean;
  onDownloadAudio: () => void;
  onSaveDialogue: () => void;
  savedCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenGenerator,
  onOpenPresets,
  onTogglePrintView,
  isPrintView,
  hasAudio,
  onDownloadAudio,
  onSaveDialogue,
  savedCount,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white px-4 lg:px-8 py-3.5 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
            <Mic className="w-5.5 h-5.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg text-slate-100 tracking-tight">
                English Dialogue Studio
              </h1>
              <span className="text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2 py-0.5 rounded-full">
                Vozes IA
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Estúdio de áudio e roteiro para aulas de inglês
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Save Script Button */}
          <button
            onClick={onSaveDialogue}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/80 border border-emerald-700/60 rounded-lg transition-colors shadow-sm"
            title="Salvar este roteiro em Meus Salvos"
          >
            <Save className="w-4 h-4 text-emerald-400" />
            <span>Salvar Roteiro</span>
          </button>

          {/* Presets & Saved Dialogues */}
          <button
            onClick={onOpenPresets}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors relative"
          >
            <BookOpen className="w-4 h-4 text-emerald-400" />
            <span>Biblioteca / Salvos</span>
            {savedCount > 0 && (
              <span className="bg-emerald-500 text-slate-950 font-bold text-[10px] px-1.5 py-0.2 rounded-full ml-1">
                {savedCount}
              </span>
            )}
          </button>

          {/* AI Generator */}
          <button
            onClick={onOpenGenerator}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 rounded-lg shadow-sm shadow-indigo-600/30 transition-all transform active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>Criar com IA</span>
          </button>

          {/* Direct Download Audio Button */}
          <button
            onClick={onDownloadAudio}
            className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all ${
              hasAudio
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-400 shadow-md shadow-emerald-500/20'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>{hasAudio ? 'Baixar Áudio WAV' : 'Gerar & Baixar Áudio'}</span>
          </button>

          {/* Printable Worksheet View */}
          <button
            onClick={onTogglePrintView}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors ${
              isPrintView
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
            }`}
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>{isPrintView ? 'Modo Edição' : 'Imprimir PDF'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
