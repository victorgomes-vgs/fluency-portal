import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Download, Sparkles, Loader2, Volume2, Gauge, CheckCircle2 } from 'lucide-react';

interface AudioPlayerBarProps {
  audioUrl?: string;
  isGeneratingAudio: boolean;
  onGenerateAudio: () => void;
  onDownloadAudio: () => void;
  onTimeUpdate?: (currentTime: number) => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  audioUrl,
  isGeneratingAudio,
  onGenerateAudio,
  onDownloadAudio,
  onTimeUpdate,
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    // Auto play when audio finishes generating
    if (audioUrl && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {});
    }
  }, [audioUrl]);

  const togglePlay = () => {
    if (!audioRef.current || !audioUrl) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((err) => console.error('Error playing audio:', err));
    }
  };

  const handleRestart = () => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = 0;
    audioRef.current.play();
    setIsPlaying(true);
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 mb-6 text-slate-100 shadow-xl relative overflow-hidden">
      {/* Background Accent glow */}
      <div className="absolute -right-20 -top-20 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 relative z-10">
        {/* Left Status & Main Generate CTA */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <button
            onClick={onGenerateAudio}
            disabled={isGeneratingAudio}
            className="flex items-center justify-center gap-2.5 px-6 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-xl shadow-lg shadow-indigo-600/30 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed w-full sm:w-auto"
          >
            {isGeneratingAudio ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-white" />
                <span>Gerando Áudio Multi-Voz...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
                <span>{audioUrl ? 'Regerar Áudio Completo' : 'Gerar Áudio do Diálogo (Multi-Voz)'}</span>
              </>
            )}
          </button>

          {/* Quick Download Button once ready */}
          {audioUrl && !isGeneratingAudio && (
            <button
              onClick={onDownloadAudio}
              className="flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl shadow-lg shadow-emerald-500/20 transition-all transform active:scale-95 w-full sm:w-auto"
            >
              <Download className="w-5 h-5 text-slate-950" />
              <span>Baixar Áudio Inteiro (.WAV)</span>
            </button>
          )}

          {!audioUrl && !isGeneratingAudio && (
            <p className="text-xs text-slate-400 max-w-xs">
              Sintetize todas as falas juntas em um único arquivo de áudio WAV para baixar ou tocar na aula.
            </p>
          )}
        </div>

        {/* Player Controls (When audio is available) */}
        {audioUrl && (
          <div className="flex-1 flex flex-col gap-3 bg-slate-950/90 border border-emerald-500/30 rounded-xl p-3.5 shadow-inner">
            <div className="flex items-center justify-between text-xs text-emerald-400 font-semibold px-1">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Áudio Multi-Voz Pronto
              </span>
              <button
                onClick={onDownloadAudio}
                className="text-xs text-emerald-300 hover:text-emerald-100 underline font-bold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                Clique aqui para baixar (.WAV)
              </button>
            </div>

            <audio
              ref={audioRef}
              src={audioUrl}
              onTimeUpdate={() => {
                if (audioRef.current) {
                  setCurrentTime(audioRef.current.currentTime);
                  onTimeUpdate?.(audioRef.current.currentTime);
                }
              }}
              onLoadedMetadata={() => {
                if (audioRef.current) {
                  setDuration(audioRef.current.duration);
                  audioRef.current.playbackRate = playbackSpeed;
                }
              }}
              onEnded={() => setIsPlaying(false)}
            />

            <div className="flex items-center gap-3">
              {/* Play / Pause */}
              <button
                onClick={togglePlay}
                className="w-10 h-10 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 flex items-center justify-center shadow-md shadow-emerald-500/30 transition-all transform active:scale-95 font-bold"
              >
                {isPlaying ? <Pause className="w-5 h-5 fill-slate-950" /> : <Play className="w-5 h-5 ml-0.5 fill-slate-950" />}
              </button>

              <button
                onClick={handleRestart}
                className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
                title="Reiniciar áudio"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Progress Slider */}
              <div className="flex-1 flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400 w-10 text-right">
                  {formatTime(currentTime)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration || 100}
                  step={0.1}
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-xs font-mono text-slate-400 w-10">
                  {formatTime(duration)}
                </span>
              </div>

              {/* Speed Selector (ESL Teaching) */}
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-lg px-2 py-1">
                <Gauge className="w-3.5 h-3.5 text-indigo-400 mr-1" />
                {[0.75, 1.0, 1.25].map((speed) => (
                  <button
                    key={speed}
                    onClick={() => handleSpeedChange(speed)}
                    className={`px-1.5 py-0.5 text-[11px] font-semibold rounded ${
                      playbackSpeed === speed
                        ? 'bg-emerald-500 text-slate-950 font-bold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {speed}x
                  </button>
                ))}
              </div>

              {/* Download WAV button in player control */}
              <button
                onClick={onDownloadAudio}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-lg border border-slate-700 transition-colors flex items-center gap-1 text-xs font-semibold"
                title="Baixar arquivo de áudio WAV"
              >
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Baixar</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
