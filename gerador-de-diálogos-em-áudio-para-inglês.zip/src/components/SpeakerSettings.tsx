import React, { useState } from 'react';
import { SpeakerConfig, VoiceName } from '../types';
import { VOICE_OPTIONS } from '../data/presets';
import { User, Volume2, Loader2, Sparkles } from 'lucide-react';

interface SpeakerSettingsProps {
  speakers: [SpeakerConfig, SpeakerConfig];
  onChangeSpeaker: (index: 0 | 1, updated: SpeakerConfig) => void;
}

export const SpeakerSettings: React.FC<SpeakerSettingsProps> = ({
  speakers,
  onChangeSpeaker,
}) => {
  const [testingVoice, setTestingVoice] = useState<string | null>(null);

  const handleTestVoice = async (speaker: SpeakerConfig) => {
    try {
      setTestingVoice(speaker.id);
      const testText = `Hello! My name is ${speaker.name}. I am using the ${speaker.voice} voice for our dialogue today.`;

      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(testText);
        utterance.lang = 'en-US';
        utterance.pitch = speaker.gender === 'female' ? 1.1 : 0.9;
        utterance.rate = 1.0;
        utterance.onend = () => setTestingVoice(null);
        utterance.onerror = () => fallbackVoiceApi(testText, speaker);
        window.speechSynthesis.speak(utterance);
        return;
      }

      await fallbackVoiceApi(testText, speaker);
    } catch (err) {
      console.error('Error testing voice preview:', err);
      setTestingVoice(null);
    }
  };

  const fallbackVoiceApi = async (testText: string, speaker: SpeakerConfig) => {
    try {
      const response = await fetch('/api/generate-line-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: testText,
          voice: speaker.voice,
          speakerName: speaker.name,
        }),
      });

      const data = await response.json();
      if (data.audioUrl) {
        const audio = new Audio(data.audioUrl);
        await audio.play();
      }
    } catch (err) {
      console.error('Fallback voice API failed:', err);
    } finally {
      setTestingVoice(null);
    }
  };

  const bgColors = [
    'bg-emerald-600',
    'bg-blue-600',
    'bg-violet-600',
    'bg-amber-600',
    'bg-rose-600',
    'bg-teal-600',
  ];

  return (
    <div className="bg-slate-900/60 backdrop-blur border border-slate-800 rounded-2xl p-5 mb-6 text-slate-100 shadow-lg">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <User className="w-5 h-5 text-indigo-400" />
            <span>Configuração das Personagens & Vozes IA</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Defina o nome de cada pessoa e escolha vozes masculinas ou femininas diferentes do Gemini.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {speakers.map((speaker, idx) => (
          <div
            key={speaker.id}
            className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-4 flex flex-col gap-3.5 relative overflow-hidden"
          >
            {/* Top Badge */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-9 h-9 rounded-full ${speaker.avatarColor} flex items-center justify-center font-bold text-white text-sm shadow-md`}
                >
                  {speaker.name.charAt(0).toUpperCase() || (idx === 0 ? 'A' : 'B')}
                </div>
                <div>
                  <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">
                    Personagem {idx + 1}
                  </span>
                  <p className="text-sm font-bold text-slate-200">{speaker.name || 'Sem nome'}</p>
                </div>
              </div>

              {/* Test Voice Button */}
              <button
                onClick={() => handleTestVoice(speaker)}
                disabled={testingVoice === speaker.id}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-indigo-900/40 hover:bg-indigo-800/60 text-indigo-300 border border-indigo-700/50 rounded-lg transition-all"
                title="Ouvir demonstração da voz"
              >
                {testingVoice === speaker.id ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                )}
                <span>Ouvir Voz</span>
              </button>
            </div>

            {/* Inputs */}
            <div className="space-y-3 pt-1">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Nome no Diálogo:
                </label>
                <input
                  type="text"
                  value={speaker.name}
                  onChange={(e) =>
                    onChangeSpeaker(idx as 0 | 1, { ...speaker, name: e.target.value })
                  }
                  className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 transition-colors"
                  placeholder={idx === 0 ? 'Ex: Anna' : 'Ex: Mark'}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Voz Inteligente Gemini:
                </label>
                <select
                  value={speaker.voice}
                  onChange={(e) => {
                    const chosen = VOICE_OPTIONS.find((v) => v.id === e.target.value);
                    onChangeSpeaker(idx as 0 | 1, {
                      ...speaker,
                      voice: e.target.value as VoiceName,
                      gender: chosen ? chosen.gender : speaker.gender,
                    });
                  }}
                  className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
                >
                  {VOICE_OPTIONS.map((opt) => (
                    <option key={opt.id} value={opt.id}>
                      {opt.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Color picker */}
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Cor de Destaque no Texto:
                </label>
                <div className="flex items-center gap-2">
                  {bgColors.map((color) => (
                    <button
                      key={color}
                      type="button"
                      onClick={() =>
                        onChangeSpeaker(idx as 0 | 1, { ...speaker, avatarColor: color })
                      }
                      className={`w-6 h-6 rounded-full ${color} transition-transform ${
                        speaker.avatarColor === color
                          ? 'ring-2 ring-white ring-offset-2 ring-offset-slate-900 scale-110'
                          : 'opacity-70 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
