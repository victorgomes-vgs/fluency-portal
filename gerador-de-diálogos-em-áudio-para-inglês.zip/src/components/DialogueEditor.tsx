import React, { useState } from 'react';
import { DialogueLine, SpeakerConfig } from '../types';
import { Plus, Trash2, ArrowUp, ArrowDown, Play, Loader2, Clipboard, AlignLeft, Edit2 } from 'lucide-react';

interface DialogueEditorProps {
  lines: DialogueLine[];
  speakers: [SpeakerConfig, SpeakerConfig];
  onChangeLines: (lines: DialogueLine[]) => void;
  activeLineId?: string;
}

export const DialogueEditor: React.FC<DialogueEditorProps> = ({
  lines,
  speakers,
  onChangeLines,
  activeLineId,
}) => {
  const [playingLineId, setPlayingLineId] = useState<string | null>(null);
  const [isQuickPasteOpen, setIsQuickPasteOpen] = useState(false);
  const [quickPasteText, setQuickPasteText] = useState('');

  const getSpeaker = (speakerId: string) => {
    return speakers.find((s) => s.id === speakerId) || speakers[0];
  };

  const handlePlayLine = async (line: DialogueLine) => {
    if (!line.text.trim()) return;
    setPlayingLineId(line.id);

    // Try browser Web Speech API for 0ms instant live playback
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); // Stop any previous speech
      const utterance = new SpeechSynthesisUtterance(line.text);
      utterance.lang = 'en-US';

      const speaker = getSpeaker(line.speakerId);
      // Adjust pitch/rate slightly based on gender to differentiate voices instantly
      if (speaker.gender === 'female') {
        utterance.pitch = 1.1;
      } else {
        utterance.pitch = 0.9;
      }
      utterance.rate = 0.95; // Clear pace for learners

      utterance.onend = () => setPlayingLineId(null);
      utterance.onerror = () => {
        // Fallback to server Gemini TTS if Web Speech fails
        fallbackGeminiTTS(line);
      };

      window.speechSynthesis.speak(utterance);
      return;
    }

    // Fallback if no window.speechSynthesis
    await fallbackGeminiTTS(line);
  };

  const fallbackGeminiTTS = async (line: DialogueLine) => {
    try {
      const speaker = getSpeaker(line.speakerId);
      const response = await fetch('/api/generate-line-audio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: line.text,
          voice: speaker.voice,
          speakerName: speaker.name,
        }),
      });

      const data = await response.json();
      if (data.audioUrl) {
        const audio = new Audio(data.audioUrl);
        await audio.play();
      }
    } catch (err) {
      console.error('Error playing single line audio:', err);
    } finally {
      setPlayingLineId(null);
    }
  };

  const handleTextChange = (id: string, newText: string) => {
    onChangeLines(lines.map((l) => (l.id === id ? { ...l, text: newText } : l)));
  };

  const handleSpeakerToggle = (id: string) => {
    onChangeLines(
      lines.map((l) => {
        if (l.id === id) {
          const nextSpeaker = l.speakerId === speakers[0].id ? speakers[1] : speakers[0];
          return {
            ...l,
            speakerId: nextSpeaker.id,
            speakerName: nextSpeaker.name,
          };
        }
        return l;
      })
    );
  };

  const handleAddLine = () => {
    const lastLine = lines[lines.length - 1];
    const nextSpeaker = lastLine
      ? lastLine.speakerId === speakers[0].id
        ? speakers[1]
        : speakers[0]
      : speakers[0];

    const newLine: DialogueLine = {
      id: `line_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      speakerId: nextSpeaker.id,
      speakerName: nextSpeaker.name,
      text: '',
    };

    onChangeLines([...lines, newLine]);
  };

  const handleDeleteLine = (id: string) => {
    if (lines.length <= 1) return;
    onChangeLines(lines.filter((l) => l.id !== id));
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= lines.length) return;

    const newLines = [...lines];
    const temp = newLines[index];
    newLines[index] = newLines[targetIdx];
    newLines[targetIdx] = temp;
    onChangeLines(newLines);
  };

  const handleParseQuickPaste = () => {
    if (!quickPasteText.trim()) return;

    const rawLines = quickPasteText.split('\n').filter((l) => l.trim().length > 0);
    const parsedLines: DialogueLine[] = [];

    rawLines.forEach((raw, idx) => {
      let speakerId = speakers[idx % 2].id;
      let speakerName = speakers[idx % 2].name;
      let lineText = raw.trim();

      // Check if line contains a colon like "Anna: Hello" or "Speaker 1: Hi"
      if (raw.includes(':')) {
        const parts = raw.split(':');
        const prefix = parts[0].trim().toLowerCase();
        lineText = parts.slice(1).join(':').trim();

        if (prefix.includes(speakers[0].name.toLowerCase()) || prefix.includes('1') || prefix.includes('a')) {
          speakerId = speakers[0].id;
          speakerName = speakers[0].name;
        } else if (
          prefix.includes(speakers[1].name.toLowerCase()) ||
          prefix.includes('2') ||
          prefix.includes('b')
        ) {
          speakerId = speakers[1].id;
          speakerName = speakers[1].name;
        }
      }

      parsedLines.push({
        id: `line_paste_${Date.now()}_${idx}`,
        speakerId,
        speakerName,
        text: lineText,
      });
    });

    if (parsedLines.length > 0) {
      onChangeLines(parsedLines);
      setQuickPasteText('');
      setIsQuickPasteOpen(false);
    }
  };

  return (
    <div className="bg-slate-900/60 backdrop-blur border border-slate-800 rounded-2xl p-5 mb-6 text-slate-100 shadow-lg">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-3 border-b border-slate-800">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <AlignLeft className="w-5 h-5 text-indigo-400" />
            <span>Roteiro do Diálogo (Falas do Texto)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Adicione, edite ou alterne as falas de cada personagem. Clique no ícone de play para ouvir frases individuais.
          </p>
        </div>

        <button
          onClick={() => setIsQuickPasteOpen(!isQuickPasteOpen)}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-indigo-300 bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-800/60 rounded-lg transition-colors self-start sm:self-auto"
        >
          <Clipboard className="w-3.5 h-3.5 text-indigo-400" />
          <span>{isQuickPasteOpen ? 'Fechar Colagem' : 'Colar Diálogo Pronto'}</span>
        </button>
      </div>

      {/* Quick Paste Area */}
      {isQuickPasteOpen && (
        <div className="bg-slate-950 border border-indigo-900/60 rounded-xl p-4 mb-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1.5">
              <Edit2 className="w-3.5 h-3.5" /> Colar texto completo
            </span>
            <span className="text-[11px] text-slate-400">
              Formato: Nome: Fala (ex: "Anna: Hello! How are you?")
            </span>
          </div>
          <textarea
            value={quickPasteText}
            onChange={(e) => setQuickPasteText(e.target.value)}
            rows={5}
            className="w-full bg-slate-900 border border-slate-700/80 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
            placeholder={`Anna: Good morning! How can I help you today?\nMark: Hi! I would like to reserve a table for two.\nAnna: Certainly! For what time?`}
          />
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setIsQuickPasteOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
            >
              Cancelar
            </button>
            <button
              onClick={handleParseQuickPaste}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors"
            >
              Processar e Substituir Falas
            </button>
          </div>
        </div>
      )}

      {/* Line Items List */}
      <div className="space-y-3">
        {lines.map((line, index) => {
          const speaker = getSpeaker(line.speakerId);
          const isActive = activeLineId === line.id;

          return (
            <div
              key={line.id}
              className={`group flex items-start gap-3 p-3.5 rounded-xl border transition-all ${
                isActive
                  ? 'bg-indigo-950/40 border-indigo-500/80 shadow-md ring-1 ring-indigo-500/50'
                  : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              {/* Speaker Toggle Badge */}
              <button
                type="button"
                onClick={() => handleSpeakerToggle(line.id)}
                title="Clique para mudar o interlocutor desta fala"
                className={`flex-shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold text-white ${speaker.avatarColor} transition-transform active:scale-95 shadow-sm`}
              >
                <span>{speaker.name || 'Personagem'}</span>
                <span className="text-[10px] opacity-75">⇄</span>
              </button>

              {/* Text Area */}
              <div className="flex-1 min-w-0">
                <textarea
                  value={line.text}
                  onChange={(e) => handleTextChange(line.id, e.target.value)}
                  rows={2}
                  className="w-full bg-slate-900/90 border border-slate-800 focus:border-indigo-500 rounded-lg px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:outline-none transition-colors resize-y min-h-[42px]"
                  placeholder="Digite a fala em inglês..."
                />
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1 pt-1 opacity-90 group-hover:opacity-100">
                {/* Play single line audio */}
                <button
                  type="button"
                  onClick={() => handlePlayLine(line)}
                  disabled={playingLineId === line.id || !line.text.trim()}
                  className="p-2 text-indigo-400 hover:text-indigo-200 hover:bg-indigo-900/30 rounded-lg transition-colors"
                  title="Ouvir esta frase individual"
                >
                  {playingLineId === line.id ? (
                    <Loader2 className="w-4 h-4 animate-spin text-indigo-400" />
                  ) : (
                    <Play className="w-4 h-4" />
                  )}
                </button>

                {/* Move Up/Down */}
                <button
                  type="button"
                  onClick={() => handleMove(index, 'up')}
                  disabled={index === 0}
                  className="p-1.5 text-slate-400 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800 transition-colors"
                  title="Mover para cima"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>

                <button
                  type="button"
                  onClick={() => handleMove(index, 'down')}
                  disabled={index === lines.length - 1}
                  className="p-1.5 text-slate-400 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800 transition-colors"
                  title="Mover para baixo"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>

                {/* Delete */}
                <button
                  type="button"
                  onClick={() => handleDeleteLine(line.id)}
                  disabled={lines.length <= 1}
                  className="p-1.5 text-rose-400 hover:text-rose-200 disabled:opacity-30 rounded hover:bg-rose-950/40 transition-colors"
                  title="Excluir fala"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Line Button */}
      <button
        onClick={handleAddLine}
        className="w-full mt-4 py-2.5 border border-dashed border-slate-700 hover:border-indigo-500/70 bg-slate-950/40 hover:bg-indigo-950/20 text-slate-300 hover:text-indigo-300 rounded-xl flex items-center justify-center gap-2 text-xs font-semibold transition-all"
      >
        <Plus className="w-4 h-4" />
        <span>Adicionar Nova Fala</span>
      </button>
    </div>
  );
};
