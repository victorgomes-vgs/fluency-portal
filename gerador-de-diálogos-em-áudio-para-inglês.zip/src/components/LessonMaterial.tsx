import React, { useState } from 'react';
import { VocabItem, QuestionItem } from '../types';
import { BookMarked, HelpCircle, CheckCircle2, XCircle, ChevronDown, ChevronUp } from 'lucide-react';

interface LessonMaterialProps {
  vocabulary?: VocabItem[];
  questions?: QuestionItem[];
}

export const LessonMaterial: React.FC<LessonMaterialProps> = ({ vocabulary, questions }) => {
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showExplanations, setShowExplanations] = useState<Record<number, boolean>>({});

  const handleSelectOption = (questionIdx: number, optionIdx: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [questionIdx]: optionIdx }));
    setShowExplanations((prev) => ({ ...prev, [questionIdx]: true }));
  };

  if ((!vocabulary || vocabulary.length === 0) && (!questions || questions.length === 0)) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Vocabulary Section */}
      {vocabulary && vocabulary.length > 0 && (
        <div className="bg-slate-900/60 backdrop-blur border border-slate-800 rounded-2xl p-5 text-slate-100 shadow-lg">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
            <BookMarked className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-slate-100">Vocabulário & Expressões Chave da Aula</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {vocabulary.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-2 hover:border-amber-500/40 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-amber-300">{item.word}</span>
                    {item.type && (
                      <span className="text-[10px] font-semibold bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full uppercase">
                        {item.type}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 mt-1">{item.definitionEn}</p>
                  <p className="text-xs text-amber-200/80 italic mt-0.5">PT: {item.definitionPt}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80">
                  <p className="text-[11px] text-slate-400">
                    <strong className="text-slate-300">Ex:</strong> "{item.example}"
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Comprehension Questions Quiz */}
      {questions && questions.length > 0 && (
        <div className="bg-slate-900/60 backdrop-blur border border-slate-800 rounded-2xl p-5 text-slate-100 shadow-lg">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-slate-800">
            <HelpCircle className="w-5 h-5 text-indigo-400" />
            <h3 className="text-base font-bold text-slate-100">Exercícios de Compreensão Auditiva</h3>
          </div>

          <div className="space-y-5">
            {questions.map((q, qIdx) => {
              const selectedOpt = selectedAnswers[qIdx];
              const isAnswered = selectedOpt !== undefined;

              return (
                <div
                  key={qIdx}
                  className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-semibold text-sm text-slate-100">
                        {qIdx + 1}. {q.questionEn}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">{q.questionPt}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {q.options.map((opt, optIdx) => {
                      const isCorrect = optIdx === q.correctAnswer;
                      const isSelected = selectedOpt === optIdx;

                      let btnStyle =
                        'bg-slate-900 border-slate-800 text-slate-300 hover:border-indigo-500/60';

                      if (isAnswered) {
                        if (isCorrect) {
                          btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200';
                        } else if (isSelected) {
                          btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200';
                        } else {
                          btnStyle = 'bg-slate-900/50 border-slate-800 text-slate-500 opacity-60';
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          type="button"
                          onClick={() => handleSelectOption(qIdx, optIdx)}
                          className={`p-3 rounded-xl border text-xs font-medium text-left flex items-center justify-between transition-all ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {isAnswered && isCorrect && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                          )}
                          {isAnswered && isSelected && !isCorrect && (
                            <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Explanation feedback */}
                  {isAnswered && (
                    <div className="mt-2 p-3 bg-indigo-950/40 border border-indigo-800/40 rounded-lg text-xs text-indigo-200">
                      <p className="font-semibold text-indigo-300">Explicação do Professor:</p>
                      <p className="mt-0.5 text-slate-300">{q.explanationPt}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
