import React, { useState } from 'react';
import { PRESET_DIALOGUES } from '../data/presets';
import { Dialogue } from '../types';
import { BookOpen, X, Check, MessageSquare, Save, Trash2, FolderOpen } from 'lucide-react';

interface PresetsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPreset: (dialogue: Dialogue) => void;
  savedDialogues: Dialogue[];
  onDeleteSaved: (id: string) => void;
  currentId?: string;
}

export const PresetsModal: React.FC<PresetsModalProps> = ({
  isOpen,
  onClose,
  onSelectPreset,
  savedDialogues,
  onDeleteSaved,
  currentId,
}) => {
  const [activeTab, setActiveTab] = useState<'presets' | 'saved'>('presets');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl text-slate-100 shadow-2xl overflow-hidden relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/20 rounded-xl border border-emerald-500/30">
              <BookOpen className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Biblioteca de Diálogos & Salvos</h3>
              <p className="text-xs text-slate-400">
                Escolha um exemplo da biblioteca ou um roteiro que você salvou anteriormente
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 pt-3 gap-4">
          <button
            onClick={() => setActiveTab('presets')}
            className={`pb-3 px-2 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'presets'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Exemplos Prontos ({PRESET_DIALOGUES.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('saved')}
            className={`pb-3 px-2 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'saved'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Save className="w-4 h-4" />
            <span>Meus Salvos ({savedDialogues.length})</span>
          </button>
        </div>

        {/* List Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {activeTab === 'presets' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PRESET_DIALOGUES.map((preset) => {
                const isSelected = currentId === preset.id;

                return (
                  <div
                    key={preset.id}
                    onClick={() => {
                      onSelectPreset(preset);
                      onClose();
                    }}
                    className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between space-y-3 group ${
                      isSelected
                        ? 'bg-emerald-950/40 border-emerald-500/80 ring-1 ring-emerald-500/50'
                        : 'bg-slate-950/80 border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/80'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-sm text-slate-100 group-hover:text-indigo-300 transition-colors">
                          {preset.title}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800/50">
                          Nível {preset.level}
                        </span>
                      </div>

                      <span className="text-[11px] text-slate-400 block mb-2">{preset.category}</span>
                      <p className="text-xs text-slate-300">{preset.description}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{preset.lines.length} falas</span>
                      </div>

                      <span className="text-indigo-400 font-semibold text-[11px] group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                        {isSelected ? 'Selecionado' : 'Carregar Este Diálogo →'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'saved' && (
            <div>
              {savedDialogues.length === 0 ? (
                <div className="text-center py-12 bg-slate-950/50 border border-slate-800 rounded-2xl p-6">
                  <FolderOpen className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <h4 className="text-sm font-bold text-slate-300">Nenhum diálogo salvo ainda</h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                    Você pode personalizar qualquer roteiro no editor e clicar no botão "Salvar Roteiro" no menu superior para guardar suas aulas aqui.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {savedDialogues.map((saved) => {
                    const isSelected = currentId === saved.id;

                    return (
                      <div
                        key={saved.id}
                        className={`p-4 rounded-xl border transition-all flex flex-col justify-between space-y-3 group ${
                          isSelected
                            ? 'bg-emerald-950/40 border-emerald-500/80 ring-1 ring-emerald-500/50'
                            : 'bg-slate-950/80 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-800/80'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-sm text-slate-100 group-hover:text-emerald-300 transition-colors">
                              {saved.title}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800/50">
                              Nível {saved.level}
                            </span>
                          </div>

                          <span className="text-[11px] text-slate-400 block mb-2">{saved.category || 'Salvo pelo Usuário'}</span>
                          <p className="text-xs text-slate-300">{saved.description}</p>
                        </div>

                        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                          <button
                            onClick={() => {
                              onSelectPreset(saved);
                              onClose();
                            }}
                            className="text-emerald-400 font-bold text-xs hover:underline flex items-center gap-1"
                          >
                            <span>{isSelected ? 'Em Uso' : 'Carregar Salvo →'}</span>
                          </button>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm(`Deseja excluir o diálogo "${saved.title}" dos seus salvos?`)) {
                                onDeleteSaved(saved.id);
                              }
                            }}
                            className="p-1.5 text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 rounded-lg transition-colors"
                            title="Excluir dos salvos"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
