import React from 'react';
import { Dialogue } from '../types';
import { Printer, ArrowLeft } from 'lucide-react';

interface PrintableLessonSheetProps {
  dialogue: Dialogue;
  onClose: () => void;
}

export const PrintableLessonSheet: React.FC<PrintableLessonSheetProps> = ({
  dialogue,
  onClose,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="bg-slate-950 min-h-screen p-4 sm:p-8 text-slate-900">
      {/* Top bar controls (hidden during print) */}
      <div className="max-w-4xl mx-auto mb-6 flex items-center justify-between print:hidden">
        <button
          onClick={onClose}
          className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Estúdio</span>
        </button>

        <button
          onClick={handlePrint}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg transition-colors"
        >
          <Printer className="w-4 h-4" />
          <span>Imprimir / Salvar em PDF</span>
        </button>
      </div>

      {/* Printable Sheet Canvas */}
      <div className="max-w-4xl mx-auto bg-white p-8 sm:p-12 rounded-2xl shadow-2xl border border-slate-200 print:shadow-none print:border-none print:p-0">
        {/* Header */}
        <div className="border-b-2 border-indigo-600 pb-4 mb-6 flex items-start justify-between">
          <div>
            <span className="text-xs font-bold tracking-widest text-indigo-600 uppercase">
              English Class Listening Activity
            </span>
            <h1 className="text-2xl font-black text-slate-900 mt-1">{dialogue.title}</h1>
            <p className="text-xs text-slate-600 mt-1">{dialogue.description}</p>
          </div>
          <div className="text-right">
            <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-800 font-bold text-xs rounded-full">
              Level: {dialogue.level}
            </span>
            <p className="text-[10px] text-slate-400 mt-2">Date: ____________</p>
            <p className="text-[10px] text-slate-400">Student Name: _________________</p>
          </div>
        </div>

        {/* Roles Legend */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6">
          <h2 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
            Speakers / Roles in Conversation:
          </h2>
          <div className="flex flex-wrap gap-6 text-xs text-slate-800 font-medium">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-600 inline-block" />
              <span>
                <strong>{dialogue.speakers[0].name}</strong> ({dialogue.speakers[0].voice} Voice)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-600 inline-block" />
              <span>
                <strong>{dialogue.speakers[1].name}</strong> ({dialogue.speakers[1].voice} Voice)
              </span>
            </div>
          </div>
        </div>

        {/* Dialogue Script */}
        <div className="mb-8 space-y-3.5">
          <h2 className="text-sm font-bold text-slate-900 border-b pb-1 mb-3">Dialogue Transcript</h2>
          {dialogue.lines.map((line, idx) => (
            <div key={line.id || idx} className="flex items-start gap-3 text-sm">
              <span className="font-bold text-indigo-950 min-w-[100px] text-right flex-shrink-0">
                {line.speakerName}:
              </span>
              <p className="text-slate-800 leading-relaxed font-normal">{line.text}</p>
            </div>
          ))}
        </div>

        {/* Vocabulary */}
        {dialogue.vocabulary && dialogue.vocabulary.length > 0 && (
          <div className="mb-8">
            <h2 className="text-sm font-bold text-slate-900 border-b pb-1 mb-3">Key Vocabulary & Expressions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {dialogue.vocabulary.map((v, i) => (
                <div key={i} className="p-3 bg-slate-50 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-indigo-900">{v.word}</span>
                    <span className="text-[10px] text-slate-500 uppercase">{v.type}</span>
                  </div>
                  <p className="text-xs text-slate-700 mt-0.5">{v.definitionEn}</p>
                  <p className="text-[11px] text-slate-500 italic">PT: {v.definitionPt}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Exercises */}
        {dialogue.questions && dialogue.questions.length > 0 && (
          <div className="mb-6">
            <h2 className="text-sm font-bold text-slate-900 border-b pb-1 mb-3">Comprehension Questions</h2>
            <div className="space-y-4">
              {dialogue.questions.map((q, idx) => (
                <div key={idx} className="text-xs space-y-1.5">
                  <p className="font-bold text-slate-900">
                    {idx + 1}. {q.questionEn}
                  </p>
                  <div className="grid grid-cols-2 gap-2 pl-4">
                    {q.options.map((opt, oIdx) => (
                      <div key={oIdx} className="flex items-center gap-2 text-slate-700">
                        <span className="w-3.5 h-3.5 border border-slate-400 rounded-full inline-block" />
                        <span>{opt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-6 border-t text-center text-[10px] text-slate-400">
          Generated with English Dialogue Studio & Gemini AI Audio Studio • Teacher Worksheet
        </div>
      </div>
    </div>
  );
};
